# CPI-Messages-Processing-Report
This package contains integration flow which will generate  CSV file of all the messages processed in the configured timer and send to mailing list.

Content Modifier Select_Minutes - configure the minutes for calculating the start and end times to fetch messages.
Contains Groovy scripts for calculation of successful and failure counts
